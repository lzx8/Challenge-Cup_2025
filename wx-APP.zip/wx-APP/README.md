# 旅游类微信小程序demo

一个旅游类型的小程序，主要用于熟悉小程序Api

## 项目截图

首页
![](screen/index.gif)

发现页
![](screen/find.gif)

地点页
![](screen/place.gif)

个人页
![](screen/me.gif)

搜索页
![](screen/search.gif)
